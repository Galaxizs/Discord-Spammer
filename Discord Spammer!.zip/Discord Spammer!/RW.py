import asyncio
import sys
import threading
from discord_webhook import DiscordWebhook
# I suck at coding py ;o;
webhook_url = input("Enter the webhook URL: ")
messages = input("Enter the messages (separated by commas): ").split(",")

def send_spam():
    print("Okay, processing spam...")
    webhook = DiscordWebhook(url=webhook_url)

    async def send_messages():
        for message in messages:
            if stop_event.is_set():
                break
            webhook.content = message.strip()
            webhook.execute()
            await asyncio.sleep(0.1)  

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(send_messages())
    loop.close()

stop_event = threading.Event()

def listen_for_stop():
    input("Press [Enter] to stop the script.")
    stop_event.set()
    sys.exit()

stop_thread = threading.Thread(target=listen_for_stop)
stop_thread.start()

send_spam()
