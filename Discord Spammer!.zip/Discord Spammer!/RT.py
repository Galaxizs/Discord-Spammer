import sys
import asyncio
from discord_webhook import DiscordWebhook

if len(sys.argv) == 1:
    token = input("Enter your token: ")
    messages = []

    print("Enter messages (one per line, enter 'done' when finished):")
    while True:
        message = input()
        if message.lower() == 'done':
            break
        messages.append(message)

    channel_id = input("Enter channel ID: ")
else:
    token = sys.argv[1]
    channel_id = sys.argv[2]
    messages = sys.argv[3:]

async def send_spam():
    webhook_url = f'https://discord.com/api/webhooks/{channel_id}/{token}'
    webhook = DiscordWebhook(url=webhook_url)
    while True:
        for message in messages:
            webhook.content = message
            webhook.execute()

            # Adjust the delay interval if desired
            await asyncio.sleep(0.2)


print("Okay, processing spam...")

loop = asyncio.get_event_loop()
task = loop.create_task(send_spam())

try:
    loop.run_until_complete(task)
except KeyboardInterrupt:
    task.cancel()
    loop.run_until_complete(task)
    loop.close()
    print("Spamming stopped.")
