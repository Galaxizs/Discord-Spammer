--------------------------------------------
Hello This is my first and last discord tool.
I won't be updating this so there will be bugs.
Youre gonna have to enter the webhook twice idk why ig I suck at coding python.
-------------------------------------------------------------------------------
Add run the Deppendencies first to install everything.
If it says python was not found add it to your PATH or disable it as a app execute aliases.